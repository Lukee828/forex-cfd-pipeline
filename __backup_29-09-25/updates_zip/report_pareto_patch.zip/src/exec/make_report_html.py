
import argparse, pandas as pd, numpy as np, math, plotly.graph_objects as go, plotly.express as px
from pathlib import Path
from datetime import datetime

def portfolio_metrics(port):
    ret = port.pct_change().dropna()
    years = (port.index[-1] - port.index[0]).days / 365.25
    cagr = port.iloc[-1] ** (1/years) - 1 if years>0 else np.nan
    vol = ret.std() * math.sqrt(252)
    downside = ret[ret<0].std() * math.sqrt(252)
    sharpe = (cagr-0.0)/vol if vol>0 else np.nan
    sortino = (cagr-0.0)/downside if downside>0 else np.nan
    dd = (port/port.cummax()-1.0)
    maxdd = dd.min()
    dd_end = dd.idxmin()
    dd_start = port.loc[:dd_end].idxmax()
    return dict(cagr=cagr, vol=vol, sharpe=sharpe, sortino=sortino, maxdd=maxdd, dd_start=dd_start, dd_end=dd_end)

def make_report(equity_csv, attrib_csv=None, monthly_csv=None, out_html='reports/report.html'):
    eq = pd.read_csv(equity_csv, parse_dates=['ts']).set_index('ts')
    port = eq['portfolio_equity']

    # Equity
    fig_eq = go.Figure()
    fig_eq.add_trace(go.Scatter(x=eq.index, y=port, name='Portfolio'))
    for c in eq.columns:
        if c.startswith('equity_'):
            fig_eq.add_trace(go.Scatter(x=eq.index, y=eq[c], name=c))
    fig_eq.update_layout(title='Equity Curves', xaxis_title='UTC Date', yaxis_title='Equity (base=1.0)')

    # Drawdown
    dd = port/port.cummax()-1.0
    fig_dd = go.Figure()
    fig_dd.add_trace(go.Scatter(x=dd.index, y=dd.values, name='Drawdown'))
    fig_dd.update_layout(title='Portfolio Drawdown', xaxis_title='UTC Date', yaxis_title='Drawdown')

    # Monthly Heatmap
    mret = (1+port.pct_change().fillna(0)).resample('M').prod()-1
    heat = mret.to_frame('ret').reset_index()
    heat['Year'] = heat['ts'].dt.year
    heat['Month'] = heat['ts'].dt.month_name().str[:3]
    pivot = heat.pivot(index='Year', columns='Month', values='ret').fillna(0)
    months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    pivot = pivot.reindex(columns=[m for m in months if m in pivot.columns])
    fig_hm = px.imshow(pivot, text_auto='.1%', aspect='auto', origin='lower', labels=dict(color='Return'))
    fig_hm.update_layout(title='Monthly Return Heatmap')

    # Attribution (auto-detect sleeves incl. vol-carry)
    fig_attr = None
    if attrib_csv and Path(attrib_csv).exists():
        attr = pd.read_csv(attrib_csv, parse_dates=['exit_time'])
        daily = attr.groupby(['exit_time','sleeve'])['pnl'].sum().unstack('sleeve').fillna(0).sort_index()
        fig_attr = go.Figure()
        for col in daily.columns:
            fig_attr.add_trace(go.Scatter(x=daily.index, y=daily[col].cumsum(), mode='lines', name=col, stackgroup='one'))
        fig_attr.update_layout(title='Cumulative Sleeve Attribution (stacked)')

    # Metrics table
    m = portfolio_metrics(port)
    metrics_html = f"""
    <table border='1' cellpadding='6' cellspacing='0'>
      <tr><th>CAGR</th><th>Vol</th><th>Sharpe</th><th>Sortino</th><th>MaxDD</th><th>DD start</th><th>DD end</th></tr>
      <tr>
        <td>{m['cagr']:.2%}</td><td>{m['vol']:.2%}</td><td>{m['sharpe']:.2f}</td>
        <td>{m['sortino']:.2f}</td><td>{m['maxdd']:.2%}</td><td>{m['dd_start'].date()}</td><td>{m['dd_end'].date()}</td>
      </tr>
    </table>
    """

    # Monthly table (optional)
    monthly_html = ''
    if monthly_csv and Path(monthly_csv).exists():
        mtab = pd.read_csv(monthly_csv, index_col=0)
        monthly_html = mtab.to_html(float_format=lambda x: f"{x:.2%}")

    # Compose HTML
    from plotly.io import to_html
    parts = [
        '<h1>Backtest Report</h1>',
        metrics_html,
        '<h2>Equity</h2>', to_html(fig_eq, include_plotlyjs='cdn', full_html=False),
        '<h2>Drawdown</h2>', to_html(fig_dd, include_plotlyjs=False, full_html=False),
        '<h2>Monthly Heatmap</h2>', to_html(fig_hm, include_plotlyjs=False, full_html=False),
    ]
    if fig_attr is not None:
        parts += ['<h2>Sleeve Attribution</h2>', to_html(fig_attr, include_plotlyjs=False, full_html=False)]
    if monthly_html:
        parts += ['<h2>Monthly Returns Table</h2>', monthly_html]

    Path(out_html).parent.mkdir(parents=True, exist_ok=True)
    with open(out_html, 'w', encoding='utf-8') as f:
        f.write('\n'.join(parts))
    print('Saved report to', out_html)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--equity_csv', default='data/pnl_demo_equity.csv')
    ap.add_argument('--attrib_csv', default='data/pnl_demo_attrib_sleeve.csv')
    ap.add_argument('--monthly_csv', default='reports/monthly_summary.csv')
    ap.add_argument('--out_html', default=None)
    args = ap.parse_args()
    out = args.out_html or f"reports/report_{datetime.now().strftime('%Y%m%d_%H%M')}.html"
    make_report(args.equity_csv, args.attrib_csv, args.monthly_csv, out)

if __name__ == '__main__':
    main()
