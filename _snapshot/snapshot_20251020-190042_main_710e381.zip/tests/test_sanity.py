def test_sanity():
    assert 2 + 2 == 4
