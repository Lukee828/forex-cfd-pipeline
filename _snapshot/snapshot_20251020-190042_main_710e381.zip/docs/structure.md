# Structure Features

- **pivot**: from ZigZag (% threshold)
- **swing**: segment-by-segment move since prior pivot
- **overbalanced**: last swing > rolling max of prior N swings
- **vol_state**: simple BBW percentile bands → {low, neutral, high}
