# Import modules for side-effect registration into the global registry
from . import sma_cross as sma_cross  # noqa: F401
from . import sma_slope as sma_slope  # noqa: F401
from . import rsi_thresh as rsi_thresh  # noqa: F401
