import os

print("=== Smoke Test ===")
print("Repo present:", os.listdir("."))
print("Loading config...")
print()
