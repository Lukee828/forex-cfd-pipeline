# Contributing

PS7 only. Pre-commit must pass (black, ruff, EOL/whitespace).
Small, focused commits; factors accept Series/DataFrame and set Series.name.
