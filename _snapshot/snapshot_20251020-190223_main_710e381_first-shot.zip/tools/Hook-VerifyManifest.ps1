param()
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

# TODO: real verification; pass for now so push is unblocked
exit 0
