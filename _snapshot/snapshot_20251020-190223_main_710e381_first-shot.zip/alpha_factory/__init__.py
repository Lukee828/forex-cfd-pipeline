from __future__ import annotations

# no magic path hacks needed; tests import our top-level shims directly
