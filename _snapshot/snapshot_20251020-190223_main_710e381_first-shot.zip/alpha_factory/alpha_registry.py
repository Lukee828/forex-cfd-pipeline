from src.registry.alpha_registry import AlphaRegistry  # noqa: F401
