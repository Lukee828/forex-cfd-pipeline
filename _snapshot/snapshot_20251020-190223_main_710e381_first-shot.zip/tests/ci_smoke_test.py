def test_ci_smoke_passes():
    # CI-only sanity: always green, catches import-level failures via collection
    assert True
