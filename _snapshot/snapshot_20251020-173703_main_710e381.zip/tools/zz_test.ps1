param()
[CmdletBinding()]
param()

Write-Host "[TEST] Hello from PS7 at $((Get-Location).Path)" -ForegroundColor Cyan
$PSVersionTable.PSVersion
