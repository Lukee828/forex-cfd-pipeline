param()
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# no-op placeholder to satisfy pre-commit
exit 0
