WIP: notes for this change
