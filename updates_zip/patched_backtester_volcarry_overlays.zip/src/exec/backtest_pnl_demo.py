
import argparse, yaml, pandas as pd, numpy as np, os
from ..core.loader import load_parquet
from ..sleeves.ts_mom import signals as ts_signals_trend
from ..sleeves.xsec_mom_simple import signals_monthly as xsec_monthly
from ..sleeves.mr_ma20_simple import signals_daily as mr_daily
from ..sleeves.vol_carry_xsec import signals_xsec_volcarry as volcarry_xsec

# ---------------- helpers ----------------

def _parse_map(s: str, cast):
    """Parse 'A:1,B:2' into dict; returns {} if empty."""
    if not s:
        return {}
    out = {}
    for kv in s.split(','):
        if not kv.strip():
            continue
        k, v = kv.split(':', 1)
        out[k.strip().upper()] = cast(v.strip())
    return out

def _load_many(paths):
    dfs = {}
    for p in paths:
        df = load_parquet(p)
        if not isinstance(df.index, pd.DatetimeIndex):
            raise ValueError(f"{p} must have DatetimeIndex")
        if df.index.tz is None:
            df.index = df.index.tz_localize("UTC")
        else:
            df.index = df.index.tz_convert("UTC")
        import pathlib
        sym = df['symbol'].dropna().iloc[0] if 'symbol' in df.columns and df['symbol'].notna().any() else pathlib.Path(p).stem.upper()
        df = df[["Open","High","Low","Close","Volume"]].dropna().sort_index()
        df['symbol'] = sym
        dfs[sym] = df
    return dfs

def _trend_signals(df, cfg, symbol):
    intents = ts_signals_trend(df_d=df.assign(symbol=symbol), lookbacks=tuple(cfg["sleeves"]["tsmom"]["lookbacks"]), exit_bars=cfg["sleeves"]["tsmom"]["exit_bars"], symbols=[symbol])
    sig = pd.Series(0, index=df.index, dtype=float)
    for oi in intents:
        if oi.symbol == symbol:
            sig.loc[pd.Timestamp(oi.ts_utc)] = 1 if oi.side=="long" else -1
    sig = sig.replace(0, np.nan).ffill().fillna(0.0)
    return sig

def _load_costs_map(path_csv: str, fallback=0.0005):
    """
    Returns dict symbol -> (entry_cost_frac, exit_cost_frac)
    If CSV missing fields, fall back to 'fallback' for that leg.
    """
    costs = {}
    if path_csv and os.path.exists(path_csv):
        tb = pd.read_csv(path_csv)
        tb['symbol'] = tb['symbol'].str.upper()
        # Support both old schema and new entry/exit schema
        cols = set(tb.columns.str.lower())
        use_entry_exit = {'entry_half_spread_bps','entry_commission_per_million','exit_half_spread_bps','exit_commission_per_million'}.issubset(cols)
        for _, r in tb.iterrows():
            s = r['symbol'].upper()
            if use_entry_exit:
                e_frac = (float(r.get('entry_half_spread_bps', np.nan))/10000.0 if pd.notna(r.get('entry_half_spread_bps', np.nan)) else np.nan) \
                       + (float(r.get('entry_commission_per_million', np.nan))/1_000_000.0 if pd.notna(r.get('entry_commission_per_million', np.nan)) else 0.0)
                x_frac = (float(r.get('exit_half_spread_bps', np.nan))/10000.0 if pd.notna(r.get('exit_half_spread_bps', np.nan)) else np.nan) \
                       + (float(r.get('exit_commission_per_million', np.nan))/1_000_000.0 if pd.notna(r.get('exit_commission_per_million', np.nan)) else 0.0)
                e_frac = e_frac if not np.isnan(e_frac) and e_frac>0 else fallback
                x_frac = x_frac if not np.isnan(x_frac) and x_frac>0 else fallback
                costs[s] = (e_frac, x_frac)
            else:
                # fallback single cost_perc column or half_spread_bps+commission without entry/exit
                if 'cost_perc' in tb.columns:
                    c = float(r['cost_perc'])
                else:
                    c = float(r.get('half_spread_bps', 0))/10000.0 + float(r.get('commission_per_million', 0))/1_000_000.0
                costs[s] = (c if c>0 else fallback, c if c>0 else fallback)
    return costs

# ---------------- simulator with overlays ----------------

def _simulate_portfolio_sync(
    dfs: dict, sides: dict, default_cost=0.0005, target_ann_vol=0.12, vol_lookback=20, max_leverage=3.0,
    mtd_soft=-0.06, mtd_hard=-0.10, costs_map=None,
    # overlays
    nav=1_000_000.0, cap_lev_map=None, cap_notional_map=None, sector_map=None, max_positions_per_sector=99
):
    """
    TRUE portfolio MTD gate; per-symbol vol targeting; entry/exit costs;
    Overlays: per-symbol leverage caps, per-symbol notional caps (uses NAV), sector guard (max open positions in a sector).
    """
    cap_lev_map = cap_lev_map or {}
    cap_notional_map = cap_notional_map or {}
    sector_map = sector_map or {}

    symbols = sorted(dfs.keys())
    # Common calendar
    cal = None
    for s in symbols:
        idx = dfs[s].index
        cal = idx if cal is None else cal.intersection(idx)
    cal = cal.sort_values()

    vol_series = {s: dfs[s]['Close'].pct_change().rolling(vol_lookback, min_periods=max(5, vol_lookback//2)).std()*np.sqrt(252.0) for s in symbols}
    leg_cost = {s: costs_map.get(s, (default_cost, default_cost)) if costs_map else (default_cost, default_cost) for s in symbols}

    pos = {s: 0 for s in symbols}
    entry = {s: None for s in symbols}
    eq = {s: 1.0 for s in symbols}
    equity_curve_rows = []
    trades_rows = []

    port_eq = 1.0
    mtd_peak = 1.0
    current_month = None

    for i, d in enumerate(cal[:-1]):
        next_d = cal[i+1]
        month_key = (d.year, d.month)
        if month_key != current_month:
            current_month = month_key
            mtd_peak = port_eq
        mtd_peak = max(mtd_peak, port_eq)
        mtd_dd = port_eq / mtd_peak - 1.0
        if mtd_dd <= mtd_hard:
            gate_mult = 0.0
        elif mtd_dd <= mtd_soft:
            gate_mult = 0.5
        else:
            gate_mult = 1.0

        for s in symbols:
            df = dfs[s]
            if d not in df.index or next_d not in df.index:
                continue
            px_next_open = float(df.loc[next_d, "Open"])
            signal = float(sides[s].get(d, 0.0))

            exit_now = False
            new_side = pos[s]
            if pos[s] != 0:
                if signal * pos[s] <= 0:
                    exit_now = True
                    new_side = int(np.sign(signal))
            else:
                if signal != 0 and gate_mult > 0.0:
                    vol_here = float(vol_series[s].loc[d]) if d in vol_series[s].index and not np.isnan(vol_series[s].loc[d]) else np.nan
                    if not np.isnan(vol_here) and vol_here > 0:
                        lev = min(max_leverage, target_ann_vol / vol_here) * gate_mult
                    else:
                        lev = 0.0
                    # --- overlays ---
                    if s in cap_lev_map:
                        lev = min(lev, float(cap_lev_map[s]))
                    if s in cap_notional_map and nav > 0:
                        lev = min(lev, float(cap_notional_map[s]) / float(nav))
                    # sector guard: block new entry if sector already at capacity
                    sec = sector_map.get(s)
                    if sec:
                        open_in_sector = sum(1 for ss in symbols if sector_map.get(ss)==sec and pos[ss]!=0)
                        if open_in_sector >= int(max_positions_per_sector):
                            lev = 0.0
                    # --------------
                    if lev > 0.0:
                        pos[s] = int(np.sign(signal))
                        entry[s] = (next_d, px_next_open, pos[s], lev, d)
                        eq[s] -= eq[s] * lev * leg_cost[s][0]

            if exit_now and entry[s] is not None:
                e_d, e_px, e_side, e_lev, sig_d = entry[s]
                ret = (px_next_open/e_px - 1.0) * e_side
                eq[s] *= (1.0 + e_lev * ret)
                eq[s] -= eq[s] * e_lev * leg_cost[s][1]
                trades_rows.append({
                    "symbol": s,
                    "entry_time": e_d,
                    "exit_time": next_d,
                    "side": "long" if e_side>0 else "short",
                    "entry_px": e_px,
                    "exit_px": px_next_open,
                    "leverage": e_lev,
                    "ret_gross": ret * e_lev,
                    "signal_date": sig_d,
                })
                entry[s] = None
                pos[s] = 0
                if new_side != 0 and gate_mult > 0.0:
                    vol_here = float(vol_series[s].loc[next_d]) if next_d in vol_series[s].index and not np.isnan(vol_series[s].loc[next_d]) else np.nan
                    if not np.isnan(vol_here) and vol_here > 0:
                        lev2 = min(max_leverage, target_ann_vol / vol_here) * gate_mult
                        # overlays on immediate reverse too
                        if s in cap_lev_map:
                            lev2 = min(lev2, float(cap_lev_map[s]))
                        if s in cap_notional_map and nav > 0:
                            lev2 = min(lev2, float(cap_notional_map[s]) / float(nav))
                        sec = sector_map.get(s)
                        if sec:
                            open_in_sector = sum(1 for ss in symbols if sector_map.get(ss)==sec and pos[ss]!=0)
                            if open_in_sector >= int(max_positions_per_sector):
                                lev2 = 0.0
                        if lev2 > 0.0:
                            pos[s] = int(np.sign(new_side))
                            entry[s] = (next_d, px_next_open, pos[s], lev2, d)
                            eq[s] -= eq[s] * lev2 * leg_cost[s][0]

        for s in symbols:
            equity_curve_rows.append((next_d, eq[s], s))
        port_eq = float(np.mean([eq[s] for s in symbols if not np.isnan(eq[s])]))

    eq_df = pd.DataFrame(equity_curve_rows, columns=["ts","equity","symbol"]).set_index("ts")
    merged = None
    for s in symbols:
        sub = eq_df[eq_df["symbol"]==s][["equity"]].rename(columns={"equity": f"equity_{s}"})
        merged = sub if merged is None else merged.join(sub, how="outer")
    merged = merged.sort_index().ffill().fillna(1.0)
    merged["portfolio_equity"] = merged.filter(like="equity_").mean(axis=1)
    trades = pd.DataFrame(trades_rows)
    return merged, trades

# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", required=True)
    ap.add_argument("--paths", default="", help="Comma-separated Parquet paths (daily bars)")
    ap.add_argument("--folder", default="", help="Folder with .parquet daily files")
    ap.add_argument("--costs_csv", default="data/costs_per_symbol.csv", help="CSV with entry/exit leg costs")
    ap.add_argument("--cost_perc", type=float, default=0.0005, help="Fallback per-leg cost fraction if symbol not in CSV")
    ap.add_argument("--target_ann_vol", type=float, default=0.12)
    ap.add_argument("--vol_lookback", type=int, default=20)
    ap.add_argument("--max_leverage", type=float, default=3.0)
    ap.add_argument("--mtd_soft", type=float, default=-0.06)
    ap.add_argument("--mtd_hard", type=float, default=-0.10)
    # sleeve weights
    ap.add_argument("--w_tsmom", type=float, default=1.0)
    ap.add_argument("--w_xsec", type=float, default=0.8)
    ap.add_argument("--w_mr", type=float, default=0.6)
    ap.add_argument("--w_volcarry", type=float, default=0.4)
    # overlays
    ap.add_argument("--nav", type=float, default=1_000_000.0)
    ap.add_argument("--max_lev_per_symbol", default="")
    ap.add_argument("--max_notional_per_symbol", default="")
    ap.add_argument("--sector_map", default="")
    ap.add_argument("--max_positions_per_sector", type=int, default=99)
    args = ap.parse_args()

    with open(args.cfg, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)

    paths = []
    if args.paths:
        paths.extend([p.strip() for p in args.paths.split(",") if p.strip()])
    if args.folder:
        import pathlib
        paths.extend([str(p) for p in pathlib.Path(args.folder).glob("*.parquet")])
    if not paths:
        raise SystemExit("Provide --paths or --folder with daily Parquet files")

    dfs = _load_many(paths)
    costs_map = _load_costs_map(args.costs_csv, fallback=args.cost_perc)

    # sleeves
    trend = {s: _trend_signals(dfs[s], cfg, s) for s in dfs.keys()}
    xsec = xsec_monthly({s: dfs[s] for s in dfs.keys()})
    mr = {s: mr_daily(dfs[s]) for s in dfs.keys()}
    volc = volcarry_xsec({s: dfs[s] for s in dfs.keys()})

    # combine
    sides = {}
    weights = {"tsmom": args.w_tsmom, "xsec": args.w_xsec, "mr": args.w_mr, "volcarry": args.w_volcarry}
    for s in dfs.keys():
        idx = dfs[s].index
        v = (trend[s].reindex(idx, method='ffill').fillna(0.0) * weights["tsmom"] +
             xsec[s].reindex(idx, method='ffill').fillna(0.0) * weights["xsec"] +
             mr[s].reindex(idx, method='ffill').fillna(0.0) * weights["mr"] +
             volc[s].reindex(idx, method='ffill').fillna(0.0) * weights["volcarry"])
        sides[s] = np.sign(v).replace(0, 0.0)

    # overlays maps
    cap_lev = _parse_map(args.max_lev_per_symbol, float)
    cap_notional = _parse_map(args.max_notional_per_symbol, float)
    sector = _parse_map(args.sector_map, str)

    merged, trades = _simulate_portfolio_sync(
        dfs, sides,
        default_cost=args.cost_perc,
        target_ann_vol=args.target_ann_vol,
        vol_lookback=args.vol_lookback,
        max_leverage=args.max_leverage,
        mtd_soft=args.mtd_soft,
        mtd_hard=args.mtd_hard,
        costs_map=costs_map,
        nav=args.nav,
        cap_lev_map=cap_lev,
        cap_notional_map=cap_notional,
        sector_map=sector,
        max_positions_per_sector=args.max_positions_per_sector
    )

    # sleeve attribution by vote magnitude at signal date for closed trades
    attrib_rows = []
    for _, row in trades.iterrows():
        s = row["symbol"]
        sig_date = pd.Timestamp(row["signal_date"])
        ws = {
            "tsmom": float(weights["tsmom"] * trend[s].reindex([sig_date], method='ffill').fillna(0.0).iloc[0]),
            "xsec":  float(weights["xsec"]  * xsec[s].reindex([sig_date], method='ffill').fillna(0.0).iloc[0]),
            "mr":    float(weights["mr"]    * mr[s].reindex([sig_date], method='ffill').fillna(0.0).iloc[0]),
            "volcarry": float(weights["volcarry"] * volc[s].reindex([sig_date], method='ffill').fillna(0.0).iloc[0]),
        }
        denom = sum(abs(w) for w in ws.values()) or 1.0
        for k in ["tsmom","xsec","mr","volcarry"]:
            attrib_rows.append({
                "exit_time": row["exit_time"],
                "symbol": s,
                "sleeve": k,
                "pnl": row["ret_gross"] * (abs(ws[k])/denom)
            })

    os.makedirs("data", exist_ok=True)
    merged.to_csv("data/pnl_demo_equity.csv", index=True)
    if len(trades):
        trades.to_csv("data/pnl_demo_trades.csv", index=False)
    if len(attrib_rows):
        pd.DataFrame(attrib_rows).to_csv("data/pnl_demo_attrib_sleeve.csv", index=False)

    start = merged.index.min()
    end = merged.index.max()
    cumret = merged["portfolio_equity"].iloc[-1] - 1.0
    nsyms = len([c for c in merged.columns if c.startswith("equity_")])
    print(f"Backtest period: {start.date()} → {end.date()} | Symbols: {nsyms}")
    print(f"Portfolio cum return (after costs): {cumret:.2%}")
    print(f"Final equity: {merged['portfolio_equity'].iloc[-1]:.4f}")
    print("Saved equity to data/pnl_demo_equity.csv")
    if len(trades): print("Saved trades to data/pnl_demo_trades.csv")
    if len(attrib_rows): print("Saved sleeve attribution to data/pnl_demo_attrib_sleeve.csv")

if __name__ == "__main__":
    main()
