import pandas as pd
import numpy as np

def signals_monthly(df_map: dict, top_q: float = 0.3, bot_q: float = 0.3) -> dict:
    """
    df_map: {symbol: daily DataFrame with columns ['Close'] index DatetimeIndex UTC}
    Returns: {symbol: pd.Series (+1/-1/0) at month-end dates, ffilled until next rebalance}
    mom12_1 = 12m momentum minus last 1m (to avoid short-term reversal)
    """
    closes = []
    symbols = list(df_map.keys())
    for s in symbols:
        c = df_map[s]['Close'].rename(s)
        closes.append(c)
    panel = pd.concat(closes, axis=1).sort_index().ffill()

    r_12m = panel / panel.shift(21*12) - 1.0
    r_1m  = panel / panel.shift(21) - 1.0
    score = r_12m - r_1m

    me = panel.index.to_series().dt.to_period('M').dt.to_timestamp('M')
    me_mask = panel.index.isin(me.unique())

    signals = {s: pd.Series(0, index=panel.index) for s in symbols}
    for dt in panel.index[me_mask]:
        sc = score.loc[dt].dropna()
        if sc.empty:
            continue
        q_hi = sc.quantile(1-top_q)
        q_lo = sc.quantile(bot_q)
        longs = sc[sc >= q_hi].index
        shorts = sc[sc <= q_lo].index
        for s in symbols:
            if s in longs:
                signals[s].loc[dt] = 1
            elif s in shorts:
                signals[s].loc[dt] = -1
            else:
                signals[s].loc[dt] = 0
    for s in symbols:
        signals[s] = signals[s].where(me_mask, np.nan).ffill().fillna(0.0)
    return signals
