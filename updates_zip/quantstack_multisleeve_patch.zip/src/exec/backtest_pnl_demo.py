import argparse, yaml, pandas as pd, numpy as np, os
from ..core.loader import load_parquet
from ..sleeves.ts_mom import signals as ts_signals_trend
from ..sleeves.xsec_mom_simple import signals_monthly as xsec_monthly
from ..sleeves.mr_ma20_simple import signals_daily as mr_daily

def _load_many(paths):
    dfs = {}
    for p in paths:
        df = load_parquet(p)
        if not isinstance(df.index, pd.DatetimeIndex):
            raise ValueError(f"{p} must have DatetimeIndex")
        if df.index.tz is None:
            df.index = df.index.tz_localize("UTC")
        else:
            df.index = df.index.tz_convert("UTC")
        import pathlib
        sym = df['symbol'].dropna().iloc[0] if 'symbol' in df.columns and df['symbol'].notna().any() else pathlib.Path(p).stem.upper()
        df = df[["Open","High","Low","Close","Volume"]].dropna().sort_index()
        df['symbol'] = sym
        dfs[sym] = df
    return dfs

def _trend_signals(df, cfg, symbol):
    intents = ts_signals_trend(df_d=df.assign(symbol=symbol), lookbacks=tuple(cfg["sleeves"]["tsmom"]["lookbacks"]), exit_bars=cfg["sleeves"]["tsmom"]["exit_bars"], symbols=[symbol])
    sig = pd.Series(0, index=df.index, dtype=float)
    for oi in intents:
        if oi.symbol == symbol:
            sig.loc[pd.Timestamp(oi.ts_utc)] = 1 if oi.side=="long" else -1
    sig = sig.replace(0, np.nan).ffill().fillna(0.0)
    return sig

def _portfolio_mtd_gate_proxy(dfs: dict, soft=-0.06, hard=-0.10):
    panel = pd.concat([dfs[s]['Close'].rename(s) for s in dfs], axis=1).sort_index().ffill()
    idx = (1 + panel.pct_change().mean(axis=1)).cumprod()
    idx.iloc[0] = 1.0
    mult = pd.Series(1.0, index=idx.index)
    by_month = idx.index.to_period('M')
    peak = 1.0
    current_m = None
    for ts in idx.index:
        m = by_month[by_month.get_loc(ts)]
        if m != current_m:
            current_m = m
            peak = idx.loc[ts]
        peak = max(peak, idx.loc[ts])
        dd = idx.loc[ts]/peak - 1.0
        if dd <= hard:
            mult.loc[ts] = 0.0
        elif dd <= soft:
            mult.loc[ts] = 0.5
        else:
            mult.loc[ts] = 1.0
    return mult

def _simulate_symbol(df, side_series, cost_perc=0.0005, target_ann_vol=0.12, vol_lookback=20, max_leverage=3.0, mtd_mult_series=None):
    dates = df.index
    pos = 0
    equity = 1.0
    equity_curve = []
    trades = []
    entry = None
    entry_leverage = 0.0
    vol = df['Close'].pct_change().rolling(vol_lookback, min_periods=max(5, vol_lookback//2)).std() * np.sqrt(252.0)

    for i, d in enumerate(dates[:-1]):
        next_d = dates[i+1]
        px_open_next = float(df.loc[next_d, "Open"])
        signal = side_series.get(d, 0.0)
        gate_mult = float(mtd_mult_series.loc[d]) if (mtd_mult_series is not None and d in mtd_mult_series.index) else 1.0

        exit_now = False
        new_side = pos
        if pos != 0:
            if signal * pos <= 0:
                exit_now = True
                new_side = int(np.sign(signal))
        else:
            if signal != 0 and gate_mult > 0.0:
                vol_here = vol.loc[d] if d in vol.index else np.nan
                if pd.isna(vol_here) or vol_here <= 0:
                    lev = 0.0
                else:
                    lev = min(max_leverage, target_ann_vol / float(vol_here))
                lev *= gate_mult
                if lev > 0.0:
                    pos = int(np.sign(signal))
                    entry_leverage = lev
                    entry = (next_d, px_open_next, pos, entry_leverage, d)
                    equity -= equity * entry_leverage * cost_perc
                    equity_curve.append((next_d, equity))
                    continue

        if exit_now and entry is not None:
            entry_d, entry_px, entry_side, lev_used, sig_date = entry
            ret = (px_open_next/entry_px - 1.0) * entry_side
            equity *= (1.0 + lev_used * ret)
            equity -= equity * lev_used * cost_perc
            trades.append({"symbol": df["symbol"].iloc[0], "entry_time": entry_d, "exit_time": next_d, "side": "long" if entry_side>0 else "short", "entry_px": entry_px, "exit_px": px_open_next, "leverage": lev_used, "ret_gross": ret * lev_used, "signal_date": sig_date})
            entry = None
            pos = 0
            entry_leverage = 0.0
            if new_side != 0 and gate_mult > 0.0:
                vol_here = vol.loc[next_d] if next_d in vol.index else np.nan
                if not pd.isna(vol_here) and vol_here > 0:
                    lev = min(max_leverage, target_ann_vol / float(vol_here))
                    lev *= gate_mult
                    if lev > 0.0:
                        pos = int(np.sign(new_side))
                        entry_leverage = lev
                        entry = (next_d, px_open_next, pos, entry_leverage, d)
                        equity -= equity * entry_leverage * cost_perc

        equity_curve.append((next_d, equity))

    eq = pd.DataFrame(equity_curve, columns=["ts","equity"]).set_index("ts")
    tr = pd.DataFrame(trades)
    return eq, tr

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", required=True)
    ap.add_argument("--paths", default="", help="Comma-separated Parquet paths (daily bars)")
    ap.add_argument("--folder", default="", help="Folder with .parquet daily files")
    ap.add_argument("--cost_perc", type=float, default=0.0005)
    ap.add_argument("--target_ann_vol", type=float, default=0.12)
    ap.add_argument("--vol_lookback", type=int, default=20)
    ap.add_argument("--max_leverage", type=float, default=3.0)
    ap.add_argument("--mtd_soft", type=float, default=-0.06)
    ap.add_argument("--mtd_hard", type=float, default=-0.10)
    ap.add_argument("--w_tsmom", type=float, default=1.0)
    ap.add_argument("--w_xsec", type=float, default=0.8)
    ap.add_argument("--w_mr", type=float, default=0.6)
    args = ap.parse_args()

    with open(args.cfg, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)

    paths = []
    if args.paths:
        paths.extend([p.strip() for p in args.paths.split(",") if p.strip()])
    if args.folder:
        import pathlib
        paths.extend([str(p) for p in pathlib.Path(args.folder).glob("*.parquet")])
    if not paths:
        raise SystemExit("Provide --paths or --folder with daily Parquet files")

    dfs = _load_many(paths)

    trend = {s: _trend_signals(dfs[s], cfg, s) for s in dfs.keys()}
    xsec = xsec_monthly({s: dfs[s] for s in dfs.keys()})
    mr = {s: mr_daily(dfs[s]) for s in dfs.keys()}

    sides = {}
    weights = {"tsmom": args.w_tsmom, "xsec": args.w_xsec, "mr": args.w_mr}
    for s in dfs.keys():
        idx = dfs[s].index
        v = (trend[s].reindex(idx, method='ffill').fillna(0.0) * weights["tsmom"] + 
             xsec[s].reindex(idx, method='ffill').fillna(0.0) * weights["xsec"] + 
             mr[s].reindex(idx, method='ffill').fillna(0.0) * weights["mr"])
        sides[s] = np.sign(v).replace(0, 0.0)

    mtd_mult = _portfolio_mtd_gate_proxy(dfs, soft=args.mtd_soft, hard=args.mtd_hard)

    all_eq = []
    all_tr = []
    attrib_rows = []
    for s, df in dfs.items():
        eq, tr = _simulate_symbol(df, sides[s], cost_perc=args.cost_perc, target_ann_vol=args.target_ann_vol, vol_lookback=args.vol_lookback, max_leverage=args.max_leverage, mtd_mult_series=mtd_mult)
        eq["symbol"] = s
        all_eq.append(eq)
        if len(tr):
            for _, row in tr.iterrows():
                sig_date = pd.Timestamp(row["signal_date"]) if not pd.isna(row["signal_date"]) else df.index[0]
                ws = {
                    "tsmom": float(weights["tsmom"] * trend[s].reindex([sig_date], method='ffill').fillna(0.0).iloc[0]),
                    "xsec":  float(weights["xsec"]  * xsec[s].reindex([sig_date], method='ffill').fillna(0.0).iloc[0]),
                    "mr":    float(weights["mr"]    * mr[s].reindex([sig_date], method='ffill').fillna(0.0).iloc[0]),
                }
                denom = sum(abs(w) for w in ws.values()) or 1.0
                for k in ["tsmom","xsec","mr"]:
                    attrib_rows.append({"exit_time": row["exit_time"], "symbol": s, "sleeve": k, "pnl": row["ret_gross"] * (abs(ws[k])/denom) })
            all_tr.append(tr)

    merged = None
    for eq in all_eq:
        col = f"equity_{eq['symbol'].iloc[0]}"
        if merged is None:
            merged = eq[["equity"]].rename(columns={"equity": col})
        else:
            merged = merged.join(eq[["equity"]].rename(columns={"equity": col}), how="outer")
    merged = merged.sort_index().ffill().fillna(1.0)
    merged["portfolio_equity"] = merged.filter(like="equity_").mean(axis=1)

    os.makedirs("data", exist_ok=True)
    out_eq = "data/pnl_demo_equity.csv"
    out_tr = "data/pnl_demo_trades.csv"
    merged.to_csv(out_eq, index=True)
    if len(all_tr):
        pd.concat(all_tr, ignore_index=True).to_csv(out_tr, index=False)
    if len(attrib_rows):
        pd.DataFrame(attrib_rows).to_csv("data/pnl_demo_attrib_sleeve.csv", index=False)

    start = merged.index.min()
    end = merged.index.max()
    cumret = merged["portfolio_equity"].iloc[-1] - 1.0
    nsyms = len(all_eq)
    print(f"Backtest period: {start.date()} → {end.date()} | Symbols: {nsyms}")
    print(f"Portfolio cum return (after costs): {cumret:.2%}")
    print(f"Final equity: {merged['portfolio_equity'].iloc[-1]:.4f}")
    print(f"Saved equity to {out_eq}")
    if len(all_tr): print(f"Saved trades to {out_tr}")
    if len(attrib_rows): print("Saved sleeve attribution to data/pnl_demo_attrib_sleeve.csv")

if __name__ == "__main__":
    main()
