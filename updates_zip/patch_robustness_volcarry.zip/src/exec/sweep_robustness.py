
import argparse, itertools, json, os, shutil, subprocess, sys, math
from datetime import datetime
from pathlib import Path
import pandas as pd
import numpy as np

def run_cmd(cmd):
    cp = subprocess.run(cmd, capture_output=True, text=True)
    if cp.returncode != 0:
        print(cp.stdout)
        print(cp.stderr)
        raise SystemExit(f"Command failed: {' '.join(cmd)}")
    return cp.stdout

def ann_metrics(equity_csv: Path):
    eq = pd.read_csv(equity_csv, parse_dates=['ts']).set_index('ts')
    port = eq['portfolio_equity'].dropna()
    ret = port.pct_change().dropna()
    years = (port.index[-1] - port.index[0]).days / 365.25
    cagr = port.iloc[-1] ** (1/years) - 1 if years>0 else np.nan
    vol = ret.std() * math.sqrt(252) if len(ret)>2 else np.nan
    dd = (port/port.cummax()-1.0)
    maxdd = dd.min() if len(dd) else np.nan
    sharpe = (cagr-0.0)/vol if isinstance(vol,float) and vol>0 else np.nan
    mar = (cagr/abs(maxdd)) if (not np.isnan(cagr) and isinstance(maxdd,float) and maxdd<0) else np.nan
    return dict(cagr=cagr, vol=vol, sharpe=sharpe, maxdd=maxdd, mar=mar)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", required=True)
    ap.add_argument("--folder", required=True)
    ap.add_argument("--costs_csv", default="data/costs_per_symbol.csv")
    # grids (comma-separated). Empty => default set
    ap.add_argument("--lookbacks_grid", default="63-126-252,42-84-168,84-168-252")
    ap.add_argument("--w_tsmom_grid", default="1.0,0.8")
    ap.add_argument("--w_xsec_grid", default="0.8,1.0,0.6")
    ap.add_argument("--w_mr_grid", default="0.6,0.4,0.8")
    ap.add_argument("--w_volcarry_grid", default="0.0,0.3,0.5")
    ap.add_argument("--target_vol_grid", default="0.10,0.12,0.15")
    ap.add_argument("--vol_lookback_grid", default="15,20,30")
    ap.add_argument("--max_lev_grid", default="2.0,3.0")
    ap.add_argument("--mtd_soft", type=float, default=-0.06)
    ap.add_argument("--mtd_hard", type=float, default=-0.10)
    ap.add_argument("--leave_one_out", action="store_true", help="Run a leave-one-out universe sweep by temporarily hiding each symbol file")
    ap.add_argument("--limit", type=int, default=0, help="Max combinations to run (0=no limit)")
    ap.add_argument("--out_root", default=None, help="Output root folder (default runs/robustness_YYYYMMDD_HHMM)")
    args = ap.parse_args()

    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    out_root = Path(args.out_root) if args.out_root else Path(f"runs/robustness_{stamp}")
    out_root.mkdir(parents=True, exist_ok=True)
    summary_rows = []

    # discover universe from folder
    sym_files = list(Path(args.folder).glob("*.parquet"))
    symbols = [p.stem.upper() for p in sym_files]

    # build grids
    def parse_list(s): return [x.strip() for x in s.split(",") if x.strip()]
    def parse_int(s): return [int(x) for x in parse_list(s)]
    def parse_float(s): return [float(x) for x in parse_list(s)]
    lookbacks_sets = [tuple(int(y) for y in trip.split("-")) for trip in parse_list(args.lookbacks_grid)]
    w_tsmom = parse_float(args.w_tsmom_grid)
    w_xsec = parse_float(args.w_xsec_grid)
    w_mr = parse_float(args.w_mr_grid)
    w_volcarry = parse_float(args.w_volcarry_grid)
    target_vol = parse_float(args.target_vol_grid)
    vol_lb = parse_int(args.vol_lookback_grid)
    max_lev = parse_float(args.max_lev_grid)

    combos = list(itertools.product(lookbacks_sets, w_tsmom, w_xsec, w_mr, w_volcarry, target_vol, vol_lb, max_lev))
    if args.limit and args.limit>0:
        combos = combos[:args.limit]

    run_id = 0
    for (lb3, wt, wx, wm, wv, tv, vlb, ml) in combos:
        run_id += 1
        run_dir = out_root / f"run_{run_id:04d}"
        run_dir.mkdir(parents=True, exist_ok=True)

        # Optionally do leave-one-out sub-sweeps
        leaveouts = [None]
        if args.leave_one_out and len(symbols) > 1:
            leaveouts = [None] + symbols

        for loo in leaveouts:
            sub_dir = run_dir if loo is None else (run_dir / f"LOO_{loo}")
            sub_dir.mkdir(parents=True, exist_ok=True)

            # Prepare temp cfg override file with the lookbacks
            cfg_override = sub_dir / "override.yaml"
            with open(cfg_override, "w", encoding="utf-8") as fh:
                fh.write(f"sleeves:\n  tsmom:\n    lookbacks: [{lb3[0]}, {lb3[1]}, {lb3[2]}]\n    exit_bars: 10\n")

            # Build folder (possibly filtered for LOO)
            folder = Path(args.folder)
            if loo is None:
                folder_use = str(folder)
            else:
                # copy to temp subfolder excluding the left-out symbol
                tmp = sub_dir / "data_subset"
                tmp.mkdir(parents=True, exist_ok=True)
                for f in sym_files:
                    if f.stem.upper() != loo:
                        dst = tmp / f.name
                        if not dst.exists():
                            import shutil; shutil.copy(f, dst)
                folder_use = str(tmp)

            # Run backtest (note: includes --w_volcarry now)
            cmd = [
                sys.executable, "-m", "src.exec.backtest_pnl_demo",
                "--cfg", str(cfg_override),
                "--folder", folder_use,
                "--costs_csv", args.costs_csv,
                "--target_ann_vol", str(tv),
                "--vol_lookback", str(vlb),
                "--max_leverage", str(ml),
                "--mtd_soft", str(args.mtd_soft),
                "--mtd_hard", str(args.mtd_hard),
                "--w_tsmom", str(wt),
                "--w_xsec", str(wx),
                "--w_mr", str(wm),
                "--w_volcarry", str(wv)
            ]
            out = run_cmd(cmd)

            # Move outputs
            eq_src = Path("data/pnl_demo_equity.csv")
            tr_src = Path("data/pnl_demo_trades.csv")
            attr_src = Path("data/pnl_demo_attrib_sleeve.csv")
            eq_dst = sub_dir / "pnl_demo_equity.csv"
            tr_dst = sub_dir / "pnl_demo_trades.csv"
            attr_dst = sub_dir / "pnl_demo_attrib_sleeve.csv"
            if eq_src.exists(): eq_dst.write_bytes(eq_src.read_bytes())
            if tr_src.exists(): tr_dst.write_bytes(tr_src.read_bytes())
            if attr_src.exists(): attr_dst.write_bytes(attr_src.read_bytes())

            # Metrics
            if eq_dst.exists():
                m = ann_metrics(eq_dst)
                row = dict(run=run_id, loo=(loo or "-"),
                           lookbacks=str(lb3), w_tsmom=wt, w_xsec=wx, w_mr=wm, w_volcarry=wv,
                           target_vol=tv, vol_lookback=vlb, max_leverage=ml,
                           cagr=m['cagr'], vol=m['vol'], sharpe=m['sharpe'], maxdd=m['maxdd'], mar=m['mar'])
                summary_rows.append(row)

        # write summary every iteration
        if summary_rows:
            pd.DataFrame(summary_rows).to_csv(out_root/"summary.csv", index=False)

    print("Saved robustness results to", out_root.resolve())

if __name__ == "__main__":
    main()
