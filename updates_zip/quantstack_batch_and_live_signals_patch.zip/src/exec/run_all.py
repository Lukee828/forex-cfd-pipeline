
import argparse, subprocess, os, shutil
from pathlib import Path
from datetime import datetime

def run(cmd):
    print(">>", " ".join(cmd))
    cp = subprocess.run(cmd, capture_output=True, text=True)
    if cp.returncode != 0:
        print(cp.stdout)
        print(cp.stderr)
        raise SystemExit(f"Command failed: {' '.join(cmd)}")
    else:
        print(cp.stdout)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", required=True)
    ap.add_argument("--folder", required=True)
    ap.add_argument("--costs_csv", default="data/costs_per_symbol.csv")
    ap.add_argument("--target_ann_vol", type=float, default=0.12)
    ap.add_argument("--vol_lookback", type=int, default=20)
    ap.add_argument("--max_leverage", type=float, default=3.0)
    ap.add_argument("--mtd_soft", type=float, default=-0.06)
    ap.add_argument("--mtd_hard", type=float, default=-0.10)
    ap.add_argument("--w_tsmom", type=float, default=1.0)
    ap.add_argument("--w_xsec", type=float, default=0.8)
    ap.add_argument("--w_mr", type=float, default=0.6)
    ap.add_argument("--nav", type=float, default=1_000_000.0)
    args = ap.parse_args()

    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    outdir = Path(f"reports/baseline_{stamp}")
    outdir.mkdir(parents=True, exist_ok=True)

    # 1) Backtest
    run(["python","-m","src.exec.backtest_pnl_demo",
         "--cfg", args.cfg,
         "--folder", args.folder,
         "--costs_csv", args.costs_csv,
         "--target_ann_vol", str(args.target_ann_vol),
         "--vol_lookback", str(args.vol_lookback),
         "--max_leverage", str(args.max_leverage),
         "--mtd_soft", str(args.mtd_soft),
         "--mtd_hard", str(args.mtd_hard),
         "--w_tsmom", str(args.w_tsmom),
         "--w_xsec", str(args.w_xsec),
         "--w_mr", str(args.w_mr)])

    # Copy equity/trades/attrib to report folder
    for fn in ["data/pnl_demo_equity.csv","data/pnl_demo_trades.csv","data/pnl_demo_attrib_sleeve.csv"]:
        p = Path(fn)
        if p.exists():
            shutil.copy(p, outdir / p.name)

    # 2) Monthly summary
    run(["python","-m","src.exec.make_monthly_summary",
         "--equity_csv", str(outdir/"pnl_demo_equity.csv"),
         "--out_csv", str(outdir/"monthly_summary.csv")])

    # 3) Metrics
    run(["python","-m","src.exec.metrics_summary",
         "--equity_csv", str(outdir/"pnl_demo_equity.csv"),
         "--trades_csv", str(outdir/"pnl_demo_trades.csv")])

    # 4) HTML report
    run(["python","-m","src.exec.make_report_html",
         "--equity_csv", str(outdir/"pnl_demo_equity.csv"),
         "--attrib_csv", str(outdir/"pnl_demo_attrib_sleeve.csv"),
         "--monthly_csv", str(outdir/"monthly_summary.csv"),
         "--out_html", str(outdir/"report.html")])

    # 5) Export today's signals (uses true MTD gate if equity exists, else proxy)
    run(["python","-m","src.exec.export_signals",
         "--cfg", args.cfg,
         "--folder", args.folder,
         "--target_ann_vol", str(args.target_ann_vol),
         "--vol_lookback", str(args.vol_lookback),
         "--max_leverage", str(args.max_leverage),
         "--w_tsmom", str(args.w_tsmom),
         "--w_xsec", str(args.w_xsec),
         "--w_mr", str(args.w_mr),
         "--mtd_soft", str(args.mtd_soft),
         "--mtd_hard", str(args.mtd_hard),
         "--equity_csv", str(outdir/"pnl_demo_equity.csv"),
         "--nav", str(args.nav),
         "--out_csv", str(outdir/"signals.csv")])

    print("All artifacts saved under", outdir.resolve())

if __name__ == "__main__":
    main()
