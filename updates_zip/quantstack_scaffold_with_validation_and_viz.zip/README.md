# QuantStack (FX/CFD Multi-Sleeve System)

Generated on 2025-09-28T10:11:35.200692Z

This is a scaffold for an **orthogonal FX/CFD strategy stack** with:
- Sleeves: TSMOM, Carry, Cross-Section Momentum, MR-VWAP, ORB/NR7, Seasonality
- Global Regime Switchbox
- Instrument Selector
- Risk Engine (vol targeting, caps, kill-switches)
- Backtest harness + Analytics

## Quick start
```bash
python -m src.exec.backtest --cfg config/base.yaml --start 2019-01-01 --end 2024-12-31 --dry-run
```


## Dukascopy ingestion

**Option A (have CSVs already):**
```bash
python -m src.data.dukascopy_downloader --symbol EURUSD --tf 1h --csv-dir /path/to/csvs --out data/prices_1h/EURUSD.parquet
```

**Option B (download via package):**
```bash
pip install dukascopy
python -m src.data.dukascopy_downloader --symbol EURUSD --tf 1h --start 2022-01-01 --end 2022-12-31 --out data/prices_1h/EURUSD.parquet
```

## TSMOM demo backtest (Parquet input)
```bash
python -m src.exec.backtest_tsmom_demo --cfg config/base.yaml --symbol EURUSD --path data/prices_1d/EURUSD.parquet
```


## Validate your Parquet library
```bash
python -m src.data.validate_library --root data --max-files 20
```
Prints per-file JSON lines with: timeframe, symbol, bar count, date range, % zero-volume, ADR median, duplicate timestamps, NaNs, weekend % (intraday).
Generated on 2025-09-28T10:32:41.713804Z
