"""
Dukascopy downloader (optional).

Usage (CLI):
    python -m src.data.dukascopy_downloader --symbol EURUSD --tf 1h --start 2022-01-01 --end 2022-12-31 --out data/prices_1h/EURUSD.parquet

It tries two methods:
  1) Use the 'dukascopy' Python package if present (pip install dukascopy).
  2) Fallback: expect pre-downloaded CSVs and convert them (see --csv-dir).

Note: Native Dukascopy .bi5 decoding is non-trivial; we recommend using the dukascopy package or exporting CSV via JForex/Dukascopy UI.
"""
import argparse, sys, pathlib, pandas as pd
from datetime import datetime

def _try_import_duka():
    try:
        import dukascopy
        return dukascopy
    except Exception:
        return None

def _save_parquet(df: pd.DataFrame, out_path: str):
    pathlib.Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_path)

def _normalize(df: pd.DataFrame, symbol: str):
    cols = {c:c.title() for c in ["open","high","low","close","volume"]}
    df = df.rename(columns=cols)
    # Accept both uppercase/lowercase 'Date'
    if "Date" not in df.columns and "date" in df.columns:
        df = df.rename(columns={"date":"Date"})
    if "Date" not in df.columns:
        raise ValueError("Input must contain a 'Date' column")
    df["symbol"] = symbol
    df = df.set_index("Date")
    # Ensure datetime
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index, utc=True)
    # Basic cleaning
    df = df[["Open","High","Low","Close","Volume","symbol"]].sort_index()
    # Drop zero-volume/weekend flats
    mask = ~((df["High"]==df["Low"]) & (df["Open"]==df["Close"]) & (df["Volume"]==0))
    return df[mask]

def _resample(df: pd.DataFrame, tf: str):
    if tf.lower() in ["1m","5m","1h","1d"]:
        rule = {"1m":"1min", "5m":"5min", "1h":"1H", "1d":"1D"}[tf.lower()]
    else:
        raise ValueError("Unsupported tf; choose from 1m,5m,1h,1d")
    o = df["Open"].resample(rule).first()
    h = df["High"].resample(rule).max()
    l = df["Low"].resample(rule).min()
    c = df["Close"].resample(rule).last()
    v = df["Volume"].resample(rule).sum()
    out = pd.concat([o,h,l,c,v], axis=1)
    out.columns = ["Open","High","Low","Close","Volume"]
    out["symbol"] = df["symbol"].resample(rule).last()
    out = out.dropna(how="any")
    return out

def from_csv_dir(csv_dir: str, symbol: str, tf: str) -> pd.DataFrame:
    csv_dir = pathlib.Path(csv_dir)
    files = sorted(csv_dir.glob("*.csv"))
    if not files:
        raise SystemExit(f"No CSV files in {csv_dir}")
    parts = []
    for f in files:
        df = pd.read_csv(f, parse_dates=["Date"])
        df = _normalize(df, symbol)
        parts.append(df)
    df = pd.concat(parts).sort_index()
    return _resample(df, tf)

def from_duka(symbol: str, tf: str, start: str, end: str) -> pd.DataFrame:
    duka = _try_import_duka()
    if duka is None:
        raise SystemExit("Package 'dukascopy' not installed. Use --csv-dir fallback or pip install dukascopy")
    # Example API sketch; actual package API may differ; adjust as needed.
    # We fetch 1-minute bars then resample to target tf to avoid vendor issues.
    start_dt = pd.Timestamp(start, tz="UTC")
    end_dt = pd.Timestamp(end, tz="UTC")
    data = duka.get_data(symbol=symbol, timeframe="m1", start=start_dt, end=end_dt)  # placeholder API
    df = data.rename(columns={"time":"Date"})  # ensure 'Date' exists
    df = _normalize(df, symbol)
    if tf.lower() != "1m":
        df = _resample(df, tf)
    return df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", required=True)
    ap.add_argument("--tf", default="1h", choices=["1m","5m","1h","1d"])
    ap.add_argument("--start", required=False, help="YYYY-MM-DD")
    ap.add_argument("--end", required=False, help="YYYY-MM-DD")
    ap.add_argument("--out", required=True, help="Parquet path, e.g. data/prices_1h/EURUSD.parquet")
    ap.add_argument("--csv-dir", required=False, help="If provided, load all CSVs from dir and resample")
    args = ap.parse_args()

    if args.csv_dir:
        df = from_csv_dir(args.csv_dir, args.symbol, args.tf)
    else:
        if not args.start or not args.end:
            raise SystemExit("When not using --csv-dir, you must pass --start and --end for download")
        df = from_duka(args.symbol, args.tf, args.start, args.end)

    _save_parquet(df, args.out)
    print(f"Saved {len(df):,} bars -> {args.out}")

if __name__ == "__main__":
    main()
