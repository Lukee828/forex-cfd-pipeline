import argparse, yaml, pandas as pd
from ..core.loader import load_parquet
from ..sleeves.ts_mom import signals as ts_signals
from ..exec.aggregate import to_net

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cfg', required=True)
    ap.add_argument('--tf', default='1d')
    ap.add_argument('--symbol', required=True)
    ap.add_argument('--path', required=True, help='Parquet path for symbol/timeframe')
    args = ap.parse_args()

    with open(args.cfg, 'r', encoding='utf-8') as fh:
        cfg = yaml.safe_load(fh)

    df = load_parquet(args.path)
    df = df.reset_index().rename(columns={'index':'Date'}).set_index('Date')
    df = df.rename(columns=str.title)
    df['symbol'] = args.symbol
    # Basic sanity
    df = df[['Open','High','Low','Close','Volume','symbol']].dropna()

    intents = ts_signals(df_d=df.reset_index().rename(columns={'Date':'ts_utc'}), lookbacks=tuple(cfg['sleeves']['tsmom']['lookbacks']), exit_bars=cfg['sleeves']['tsmom']['exit_bars'], symbols=[args.symbol])
    net = to_net(intents)
    print(f"Signals generated: {len(intents)}, Net positions after aggregation: {len(net)}")
    # Print first 10
    for oi in net[:10]:
        print(oi.ts_utc, oi.symbol, oi.side, oi.tag)

if __name__ == '__main__':
    main()
