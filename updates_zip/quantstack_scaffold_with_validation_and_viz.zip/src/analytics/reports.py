def generate(results=None, state=None, universe=None, out_path='reports/latest.pdf'):
    # Placeholder; integrate your existing PDF generator here
    return out_path
