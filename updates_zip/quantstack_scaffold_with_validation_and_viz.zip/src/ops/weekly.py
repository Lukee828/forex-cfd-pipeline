def run():
    print('Weekly ops placeholder')
