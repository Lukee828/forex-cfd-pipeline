def run():
    print('Monthly ops placeholder')
