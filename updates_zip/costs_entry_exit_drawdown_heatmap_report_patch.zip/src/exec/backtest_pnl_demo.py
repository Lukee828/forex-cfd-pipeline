# patched backtester with true portfolio MTD and entry/exit costs
