import argparse, yaml, pandas as pd, numpy as np
from ..core.loader import load_parquet
from ..sleeves.ts_mom import signals as ts_signals
from ..exec.aggregate import to_net

# Minimal daily PnL backtester for Donchian TSMOM signals
# - Loads daily Parquet(s)
# - Generates signals
# - Simulates fills at next day's open
# - Tracks equity with simple cost model
# - Outputs equity and trades CSV

def _load_many(paths):
    dfs = []
    for p in paths:
        df = load_parquet(p)
        if not isinstance(df.index, pd.DatetimeIndex):
            raise ValueError(f"{p} must have DatetimeIndex")
        if df.index.tz is None:
            df.index = df.index.tz_localize("UTC")
        else:
            df.index = df.index.tz_convert("UTC")
        if "symbol" not in df.columns or df["symbol"].isna().all():
            import pathlib
            df = df.copy()
            df["symbol"] = pathlib.Path(p).stem.upper()
        df = df[["Open","High","Low","Close","Volume","symbol"]].dropna().sort_index()
        dfs.append(df)
    return dfs

def _intents_by_symbol(df, cfg, symbol):
    intents = ts_signals(df_d=df, lookbacks=tuple(cfg["sleeves"]["tsmom"]["lookbacks"]), exit_bars=cfg["sleeves"]["tsmom"]["exit_bars"], symbols=[symbol])
    sig_map = {}
    for oi in intents:
        if oi.symbol != symbol:
            continue
        sig_map[pd.Timestamp(oi.ts_utc)] = 1 if oi.side=="long" else -1
    return sig_map

def _simulate_symbol(df, sig_map, exit_bars=80, cost_perc=0.0005):
    dates = df.index
    pos, bars_in_pos, equity = 0, 0, 1.0
    equity_curve, trades, entry = [], [], None
    for i, d in enumerate(dates[:-1]):
        next_d = dates[i+1]
        px_open_next = float(df.loc[next_d, "Open"])
        signal = sig_map.get(d, 0)
        exit_now, new_side = False, pos
        if pos != 0:
            bars_in_pos += 1
            if signal * pos == -1 or bars_in_pos >= exit_bars:
                exit_now, new_side = True, signal if signal*pos==-1 else 0
        elif signal != 0:
            pos, bars_in_pos, entry = signal, 0, (next_d, px_open_next, signal)
            equity -= equity * cost_perc
            equity_curve.append((next_d, equity))
            continue
        if exit_now and entry:
            entry_d, entry_px, entry_side = entry
            ret = (px_open_next/entry_px - 1.0)*entry_side
            equity *= (1.0+ret)
            equity -= equity * cost_perc
            trades.append({"symbol": df["symbol"].iloc[0], "entry_time": entry_d, "exit_time": next_d, "side": "long" if entry_side>0 else "short", "entry_px": entry_px, "exit_px": px_open_next, "ret_net_before_costs": ret})
            entry, pos, bars_in_pos = None, 0, 0
            if new_side != 0:
                pos, bars_in_pos, entry = new_side, 0, (next_d, px_open_next, new_side)
                equity -= equity * cost_perc
        equity_curve.append((next_d, equity))
    eq = pd.DataFrame(equity_curve, columns=["ts","equity"]).set_index("ts")
    tr = pd.DataFrame(trades)
    return eq, tr

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", required=True)
    ap.add_argument("--paths", default="", help="Comma-separated Parquet paths (daily bars)")
    ap.add_argument("--folder", default="", help="Folder with .parquet daily files")
    ap.add_argument("--cost_perc", type=float, default=0.0005)
    args = ap.parse_args()
    with open(args.cfg,"r",encoding="utf-8") as fh: cfg = yaml.safe_load(fh)
    paths=[]; 
    if args.paths: paths.extend([p.strip() for p in args.paths.split(",") if p.strip()])
    if args.folder: import pathlib; paths.extend([str(p) for p in pathlib.Path(args.folder).glob("*.parquet")])
    if not paths: raise SystemExit("Provide --paths or --folder with daily Parquet files")
    dfs=_load_many(paths); all_eq,all_trades=[],[]
    for df in dfs:
        sym=df["symbol"].iloc[0]; sig_map=_intents_by_symbol(df,cfg,sym)
        eq,tr=_simulate_symbol(df,sig_map,exit_bars=cfg["sleeves"]["tsmom"]["exit_bars"],cost_perc=args.cost_perc)
        eq["symbol"]=sym; all_eq.append(eq)
        if len(tr): all_trades.append(tr)
    merged=None
    for eq in all_eq:
        if merged is None: merged=eq[["equity"]].rename(columns={"equity":f"equity_{eq['symbol'].iloc[0]}"})
        else: merged=merged.join(eq[["equity"]].rename(columns={"equity":f"equity_{eq['symbol'].iloc[0]}"}),how="outer")
    merged=merged.fillna(method="ffill").fillna(1.0); merged["portfolio_equity"]=merged.filter(like="equity_").mean(axis=1)
    start,end=merged.index.min(),merged.index.max()
    cumret=merged["portfolio_equity"].iloc[-1]-1.0; nsyms=len(all_eq)
    print(f"Backtest period: {start.date()} → {end.date()} | Symbols: {nsyms}")
    print(f"Portfolio cum return (after costs): {cumret:.2%}")
    print(f"Final equity: {merged['portfolio_equity'].iloc[-1]:.4f}")
    out_eq="data/pnl_demo_equity.csv"; out_tr="data/pnl_demo_trades.csv"
    merged.to_csv(out_eq); 
    if all_trades: pd.concat(all_trades,ignore_index=True).to_csv(out_tr,index=False); print(f"Saved trades to {out_tr}")
    print(f"Saved equity to {out_eq}")

if __name__=="__main__": main()
