
import argparse, yaml, pandas as pd, numpy as np
from ..core.loader import load_parquet
from ..sleeves.ts_mom import signals as ts_signals

def _load_many(paths):
    dfs = []
    for p in paths:
        df = load_parquet(p)
        if not isinstance(df.index, pd.DatetimeIndex):
            raise ValueError(f"{p} must have DatetimeIndex")
        if df.index.tz is None:
            df.index = df.index.tz_localize("UTC")
        else:
            df.index = df.index.tz_convert("UTC")
        if "symbol" not in df.columns or df["symbol"].isna().all():
            import pathlib
            df = df.copy()
            df["symbol"] = pathlib.Path(p).stem.upper()
        df = df[["Open","High","Low","Close","Volume","symbol"]].dropna().sort_index()
        dfs.append(df)
    return dfs

def _intents_by_symbol(df, cfg, symbol):
    intents = ts_signals(
        df_d=df,
        lookbacks=tuple(cfg["sleeves"]["tsmom"]["lookbacks"]),
        exit_bars=cfg["sleeves"]["tsmom"]["exit_bars"],
        symbols=[symbol],
    )
    sig_map = {}
    for oi in intents:
        if oi.symbol != symbol:
            continue
        sig_map[pd.Timestamp(oi.ts_utc)] = 1 if oi.side == "long" else -1
    return sig_map

def _realized_vol(close: pd.Series, lookback=20) -> pd.Series:
    r = close.pct_change()
    vol = r.rolling(lookback, min_periods=lookback//2).std() * np.sqrt(252.0)
    return vol

def _simulate_symbol(
    df,
    sig_map,
    exit_bars=80,
    cost_perc=0.0005,
    target_ann_vol=0.12,
    vol_lookback=20,
    max_leverage=3.0,
    mtd_soft=-0.06,
    mtd_hard=-0.10,
):
    """
    Daily simulation (next-open fills) with:
      - per-entry vol targeting (units = target_vol / realized_vol, capped)
      - simple per-leg costs (percentage of deployed notional)
      - per-symbol MTD drawdown gates (soft: halve size, hard: stop until next month)
    """
    dates = df.index
    pos = 0
    bars_in_pos = 0
    equity = 1.0
    equity_curve = []
    trades = []
    entry = None
    entry_leverage = 0.0  # leverage used for the open position

    # Volatility series for sizing at each entry
    vol_series = _realized_vol(df["Close"], lookback=vol_lookback)

    # MTD gates (per symbol approximation)
    current_month = None
    mtd_peak = 1.0
    mtd_floor_soft = None
    mtd_floor_hard = None
    mtd_state = "normal"  # normal | soft | hard

    for i, d in enumerate(dates[:-1]):
        next_d = dates[i + 1]
        px_open_next = float(df.loc[next_d, "Open"])
        signal = sig_map.get(d, 0)

        # Update MTD state at month boundaries
        if current_month != (d.year, d.month):
            current_month = (d.year, d.month)
            mtd_peak = equity
            mtd_floor_soft = mtd_peak * (1.0 + mtd_soft)
            mtd_floor_hard = mtd_peak * (1.0 + mtd_hard)
            mtd_state = "normal"

        # Check MTD drawdown status
        if equity > mtd_peak:
            mtd_peak = equity
            mtd_floor_soft = mtd_peak * (1.0 + mtd_soft)
            mtd_floor_hard = mtd_peak * (1.0 + mtd_hard)

        if equity <= mtd_floor_hard:
            mtd_state = "hard"
        elif equity <= mtd_floor_soft and mtd_state != "hard":
            mtd_state = "soft"

        size_multiplier = 1.0 if mtd_state == "normal" else (0.5 if mtd_state == "soft" else 0.0)

        # Exit conditions
        exit_now = False
        new_side = pos

        if pos != 0:
            bars_in_pos += 1
            if signal * pos == -1:  # opposite
                exit_now = True
                new_side = signal
            elif bars_in_pos >= exit_bars:
                exit_now = True
                new_side = 0
        else:
            # Consider entry only if not hard-stopped
            if signal != 0 and size_multiplier > 0.0:
                # per-entry leverage based on realized vol at d
                vol_here = float(vol_series.loc[d]) if d in vol_series.index and not np.isnan(vol_series.loc[d]) else None
                if vol_here is None or vol_here <= 0.0 or np.isnan(vol_here):
                    lev = 0.0
                else:
                    lev = min(max_leverage, target_ann_vol / vol_here)
                # apply soft gate
                lev *= size_multiplier

                if lev > 0.0:
                    pos = signal
                    entry_leverage = lev
                    bars_in_pos = 0
                    entry = (next_d, px_open_next, pos, entry_leverage)
                    # entry cost proportional to deployed notional (equity * lev)
                    equity -= equity * entry_leverage * cost_perc
                    equity_curve.append((next_d, equity, mtd_state))
                    continue

        if exit_now and entry is not None:
            # Close at next open
            entry_d, entry_px, entry_side, lev_used = entry
            ret = (px_open_next / entry_px - 1.0) * entry_side
            equity *= (1.0 + lev_used * ret)
            equity -= equity * lev_used * cost_perc  # exit cost
            trades.append({
                "symbol": df["symbol"].iloc[0],
                "entry_time": entry_d,
                "exit_time": next_d,
                "side": "long" if entry_side > 0 else "short",
                "entry_px": entry_px,
                "exit_px": px_open_next,
                "leverage": lev_used,
                "ret_gross": ret * lev_used,
            })
            entry = None
            pos = 0
            bars_in_pos = 0
            entry_leverage = 0.0

            # Reverse if needed, respecting MTD gate
            if new_side != 0 and size_multiplier > 0.0:
                vol_here = float(vol_series.loc[next_d]) if next_d in vol_series.index and not np.isnan(vol_series.loc[next_d]) else None
                if vol_here is None or vol_here <= 0.0 or np.isnan(vol_here):
                    lev = 0.0
                else:
                    lev = min(max_leverage, target_ann_vol / vol_here)
                lev *= size_multiplier
                if lev > 0.0:
                    pos = new_side
                    entry_leverage = lev
                    bars_in_pos = 0
                    entry = (next_d, px_open_next, pos, entry_leverage)
                    equity -= equity * entry_leverage * cost_perc

        equity_curve.append((next_d, equity, mtd_state))

    eq = pd.DataFrame(equity_curve, columns=["ts", "equity", "mtd_state"]).set_index("ts")
    tr = pd.DataFrame(trades)
    return eq, tr

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", required=True)
    ap.add_argument("--paths", default="", help="Comma-separated Parquet paths (daily bars)")
    ap.add_argument("--folder", default="", help="Folder with .parquet daily files")
    ap.add_argument("--cost_perc", type=float, default=0.0005, help="Per-trade leg cost as fraction of notional (e.g., 0.0005 = 5 bps)")
    ap.add_argument("--target_ann_vol", type=float, default=0.12, help="Per-symbol target annualized volatility for sizing")
    ap.add_argument("--vol_lookback", type=int, default=20, help="Lookback days for realized vol")
    ap.add_argument("--max_leverage", type=float, default=3.0, help="Cap on per-entry leverage")
    ap.add_argument("--mtd_soft", type=float, default=-0.06, help="Soft MTD DD (fraction) where size halves")
    ap.add_argument("--mtd_hard", type=float, default=-0.10, help="Hard MTD DD (fraction) where trading stops until next month")
    args = ap.parse_args()

    with open(args.cfg, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)

    paths = []
    if args.paths:
        paths.extend([p.strip() for p in args.paths.split(",") if p.strip()])
    if args.folder:
        import pathlib
        paths.extend([str(p) for p in pathlib.Path(args.folder).glob("*.parquet")])
    if not paths:
        raise SystemExit("Provide --paths or --folder with daily Parquet files")

    dfs = _load_many(paths)

    all_eq = []
    all_trades = []
    for df in dfs:
        sym = df["symbol"].iloc[0]
        sig_map = _intents_by_symbol(df, cfg, sym)
        eq, tr = _simulate_symbol(
            df,
            sig_map,
            exit_bars=cfg["sleeves"]["tsmom"]["exit_bars"],
            cost_perc=args.cost_perc,
            target_ann_vol=args.target_ann_vol,
            vol_lookback=args.vol_lookback,
            max_leverage=args.max_leverage,
            mtd_soft=args.mtd_soft,
            mtd_hard=args.mtd_hard,
        )
        eq["symbol"] = sym
        all_eq.append(eq)
        if len(tr):
            all_trades.append(tr)

    # Aggregate portfolio = equal-weight average
    merged = None
    for eq in all_eq:
        col = f"equity_{eq['symbol'].iloc[0]}"
        if merged is None:
            merged = eq[["equity"]].rename(columns={"equity": col})
        else:
            merged = merged.join(eq[["equity"]].rename(columns={"equity": col}), how="outer")
    merged = merged.sort_index().fillna(method="ffill").fillna(1.0)
    merged["portfolio_equity"] = merged.filter(like="equity_").mean(axis=1)

    start = merged.index.min()
    end = merged.index.max()
    cumret = merged["portfolio_equity"].iloc[-1] - 1.0
    nsyms = len(all_eq)
    print(f"Backtest period: {start.date()} → {end.date()} | Symbols: {nsyms}")
    print(f"Portfolio cum return (after costs): {cumret:.2%}")
    print(f"Final equity: {merged['portfolio_equity'].iloc[-1]:.4f}")

    out_eq = "data/pnl_demo_equity.csv"
    out_tr = "data/pnl_demo_trades.csv"
    merged.to_csv(out_eq, index=True)
    if all_trades:
        import pandas as pd
        pd.concat(all_trades, ignore_index=True).to_csv(out_tr, index=False)
        print(f"Saved trades to {out_tr}")
    print(f"Saved equity to {out_eq}")

if __name__ == "__main__":
    main()
